from Bat import Bat

class MyBat(Bat):
    def run(self):
        self.setWingAppearance("11110011")
        self.setBodyAppearance("10000011")
        self.setColour((170,170,220))
        while True:
            self.setSpeed(1.0)
            result = self.ping()
            if(result["distance"] == 0): self.turnLeft()
