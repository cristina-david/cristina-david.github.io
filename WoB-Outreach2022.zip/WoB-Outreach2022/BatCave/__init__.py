from BatCave.YourBatsName.MyBat import MyBat
from BatCave.Simon.MyBat import MyBat
