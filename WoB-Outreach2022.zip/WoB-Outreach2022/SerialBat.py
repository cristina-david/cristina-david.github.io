from Bat import Bat
import os, serial

PING = int("00000000", 2)
RIGHT = int("00000001", 2)
LEFT = int("00000010", 2)

class SerialBat(Bat):

    def __init__(self, serialPortName, world):
        self.serialPortName = serialPortName
        Bat.__init__(self, world)

    def run(self):
        self.serialPort = serial.Serial(self.serialPortName, 115200)
        self.setName(self.serialPort.readline().strip().decode("utf-8"))
        self.setWingAppearance(convertToBinaryString(self.serialPort.read(1)))
        self.setBodyAppearance(convertToBinaryString(self.serialPort.read(1)))
        red = ord(self.serialPort.read(1))
        green = ord(self.serialPort.read(1))
        blue = ord(self.serialPort.read(1))
        self.setColour((red,green,blue))
        while True:
            if self.serialPort.in_waiting:
                command = self.serialPort.read(1)
                if ord(command) == PING:
                    result = self.ping()
                    self.serialPort.write(chr(result["distance"]).encode())
                    self.serialPort.write(chr(result["size"]).encode())
                elif ord(command) == RIGHT: self.turnRight()
                elif ord(command) == LEFT: self.turnLeft()
                elif ord(command) > 128:
                    # Convert speed from range of 128->255 to 0.0->1.0
                    newSpeed = float(ord(command) - 128.0)/128.0
                    self.setSpeed(newSpeed)

def convertToBinaryString(byte):
    string = format(ord(byte),"b")
    while len(string) < 8: string = "0" + string
    return string
